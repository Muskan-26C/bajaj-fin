export const API_URL = 'http://localhost:3000';
export const USER_ID = 'john_doe_17091999';
export const EMAIL = 'john@xyz.com';
export const ROLL_NUMBER = 'ABCD123';