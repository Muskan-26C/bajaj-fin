import React, { useState } from 'react';
import { AlertCircle, CheckCircle2 } from 'lucide-react';
import Select from 'react-select';
import toast from 'react-hot-toast';
import { BFHLRequest, BFHLResponse, FilterOption } from './types';
import { USER_ID, EMAIL, ROLL_NUMBER } from './config';

function App() {
  const [jsonInput, setJsonInput] = useState('');
  const [response, setResponse] = useState<BFHLResponse | null>(null);
  const [selectedFilters, setSelectedFilters] = useState<FilterOption[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const filterOptions = [
    { value: 'numbers' as FilterOption, label: 'Numbers' },
    { value: 'alphabets' as FilterOption, label: 'Alphabets' },
    { value: 'highest_alphabet' as FilterOption, label: 'Highest Alphabet' }
  ];

  const processData = (data: string[]): BFHLResponse => {
    const numbers = data.filter(item => !isNaN(Number(item)));
    const alphabets = data.filter(item => /^[A-Za-z]$/.test(item));
    const highest_alphabet = alphabets.length > 0 
      ? [alphabets.reduce((a, b) => a.toLowerCase() > b.toLowerCase() ? a : b)]
      : [];

    return {
      is_success: true,
      user_id: USER_ID,
      email: EMAIL,
      roll_number: ROLL_NUMBER,
      numbers,
      alphabets,
      highest_alphabet
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      // Validate JSON input
      const parsedInput = JSON.parse(jsonInput) as BFHLRequest;
      
      if (!Array.isArray(parsedInput.data)) {
        throw new Error('Input must contain a "data" array');
      }

      // Process the data
      const result = processData(parsedInput.data);
      setResponse(result);
      toast.success('Data processed successfully!');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Invalid JSON input');
      toast.error('Invalid input format');
    } finally {
      setLoading(false);
    }
  };

  const renderFilteredResponse = () => {
    if (!response || selectedFilters.length === 0) return null;

    return (
      <div className="mt-6 space-y-4">
        {selectedFilters.includes('numbers') && response.numbers.length > 0 && (
          <div>
            <h3 className="font-semibold text-gray-700">Numbers:</h3>
            <p className="mt-1">[{response.numbers.join(', ')}]</p>
          </div>
        )}
        {selectedFilters.includes('alphabets') && response.alphabets.length > 0 && (
          <div>
            <h3 className="font-semibold text-gray-700">Alphabets:</h3>
            <p className="mt-1">[{response.alphabets.join(', ')}]</p>
          </div>
        )}
        {selectedFilters.includes('highest_alphabet') && response.highest_alphabet.length > 0 && (
          <div>
            <h3 className="font-semibold text-gray-700">Highest Alphabet:</h3>
            <p className="mt-1">[{response.highest_alphabet.join(', ')}]</p>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6 space-y-6">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-gray-900">BFHL Data Processor</h1>
            <p className="mt-2 text-gray-600">Enter JSON data to process</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="json-input" className="block text-sm font-medium text-gray-700">
                JSON Input
              </label>
              <textarea
                id="json-input"
                rows={4}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                placeholder={'{ "data": ["M","1","334","4","B"] }'}
                value={jsonInput}
                onChange={(e) => setJsonInput(e.target.value)}
              />
            </div>

            {error && (
              <div className="rounded-md bg-red-50 p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <AlertCircle className="h-5 w-5 text-red-400" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-red-800">{error}</h3>
                  </div>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className={`w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
                loading
                  ? 'bg-indigo-400 cursor-not-allowed'
                  : 'bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500'
              }`}
            >
              {loading ? 'Processing...' : 'Process Data'}
            </button>
          </form>

          {response && (
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-green-600">
                <CheckCircle2 className="h-5 w-5" />
                <span className="font-medium">Data processed successfully!</span>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select filters to display
                </label>
                <Select
                  isMulti
                  options={filterOptions}
                  value={filterOptions.filter(option => 
                    selectedFilters.includes(option.value)
                  )}
                  onChange={(selected) => 
                    setSelectedFilters(selected.map(option => option.value))
                  }
                  className="basic-multi-select"
                  classNamePrefix="select"
                />
              </div>

              {renderFilteredResponse()}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;